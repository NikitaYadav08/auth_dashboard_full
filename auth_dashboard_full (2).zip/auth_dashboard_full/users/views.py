from django.shortcuts import render, redirect
from django.contrib import messages
from .models import UserProfile

def onboarding(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        company = request.POST.get('company', '')
        industry = request.POST.get('industry', '')
        size = request.POST.get('size', '')
        theme = request.POST.get('theme', 'light')
        layout = request.POST.get('layout', 'grid')

        if UserProfile.objects.filter(email=email).exists():
            messages.error(request, 'This email is already registered. Please use a different email.')
            return render(request, 'users/onboarding.html', {
                'name': name,
                'email': email,
                'company': company,
                'industry': industry,
                'size': size,
                'theme': theme,
                'layout': layout,
            })

        UserProfile.objects.create(
            name=name,
            email=email,
            company=company,
            industry=industry,
            size=size,
            theme=theme,
            layout=layout
        )
        return redirect('dashboard')
    else:
        return render(request, 'users/onboarding.html')


def dashboard(request):
    user = UserProfile.objects.last()
    return render(request, 'users/dashboard.html', {
        'user': user,
        'theme': user.theme if user else 'light',
        'layout': user.layout if user else 'grid',
    })


