from django import forms

class OnboardingForm(forms.Form):
    name = forms.CharField()
    email = forms.EmailField()